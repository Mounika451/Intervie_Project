var express=require("express")
var app=express()
var routes=requir("./routes/index.js")

app.use("/",routes)

app.listen(8900,()=>{
    console.log("Listing_port")
})

module.exports.app=app