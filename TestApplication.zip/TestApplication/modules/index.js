var MongoClient = require('mongodb').MongoClient;

var localDbUrl = "mongodb://xxx:yyyy@00.00.00.00/?authSource=admin'";

module.exports=async function(req,res){
    try{
        let local_connection = await MongoClient.connect(localDbUrl, {useNewUrlParser: true,connectTimeoutMS: 90000, socketTimeoutMS: 90000});
        let mongo_details= {
            database: "data_us",
            collection: "testing_xml_data_10112022" 
        }
        let database =await local_connection.db(mongo_details["database"]);
        let collection =await database.collection(mongo_details["collection"]);
        if(!req || !req.body){
            res.send({"status":404,"message":"Invalid Input"})
        }
        let reqBody=req.body
        let records=await collection.find(reqBody).toArray()

        res.send({"status":200,"message":"success","result":records})

    }catch(edd){
        res.send({"status":500,"message":"error"})
    }
}