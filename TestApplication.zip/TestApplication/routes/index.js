var router_obj=require("express").Router
var get_details=require("../modules/index.js")

router_obj.route("/get_details").post(get_details)

module.exports.router_obj=router_obj